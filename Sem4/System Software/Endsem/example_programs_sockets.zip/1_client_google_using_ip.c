// We want to connect to the Google server - which is a live web server

/* To compile this program use the following command */
/* $ gcc 1_client_google_using_ip.c -o 1.o */

/* To run this program use the following command */
/* $ ./1.o */

#include<stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h> 
#include<sys/socket.h>
#include<arpa/inet.h>	//inet_addr
#include <netinet/in.h>

int main(int argc , char *argv[])
{
	int socket_desc;
        struct sockaddr_in server;
	
	//Create socket
	socket_desc = socket(AF_INET , SOCK_STREAM , 0);

	if (socket_desc == -1)
	{
		printf("Could not create socket");
	}

	// check IP address passed to inet_addr() using other program client_get_server_ip_address.c as it keeps changing

	server.sin_addr.s_addr = inet_addr("172.217.166.68");  
	server.sin_family = AF_INET;
	server.sin_port = htons( 80 );

	//Connect to remote server
	if (connect(socket_desc , (struct sockaddr *)&server , sizeof(server)) < 0)
	{
		puts("connect error");
		return 1;
	}
	
	puts("Connected");
	return 0;
}
