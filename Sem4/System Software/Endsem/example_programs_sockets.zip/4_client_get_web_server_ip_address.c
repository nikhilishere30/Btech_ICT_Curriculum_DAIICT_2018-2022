/* To compile this program use the following command */
/* $ gcc 4_client_get_web_server_ip_address.c -o 4.o */

/* To run this program use the following command */
/* $ ./4.o */

#include<stdio.h> //printf
#include<string.h> //strcpy
#include<sys/socket.h>
#include<netdb.h>	//hostent
#include<arpa/inet.h>

int main(int argc , char *argv[])
{
	char *hostname, *input_hostname;
	char ip[100];
	struct hostent *he;
	struct in_addr **addr_list;
	int i;
		
        while(1){
        printf("Enter hostname for which you want to fetch the IP address:");
        scanf("%s",hostname);
        input_hostname = hostname;     // Just to store it for use in the program later using input_hostname

	if ( (he = gethostbyname( hostname ) ) == NULL) 
	{
		//gethostbyname failed
		herror("gethostbyname");
		return 1;
	}
	
	//Cast the h_addr_list to in_addr , since h_addr_list also has the ip address in long format only
	addr_list = (struct in_addr **) he->h_addr_list;
	
	for(i = 0; addr_list[i] != NULL; i++) 
	{
		//Return the first one;
		strcpy(ip , inet_ntoa(*addr_list[i]) );
	}
	        
	printf(" %s Host name resolved to IP address: %s\n\n" , input_hostname , ip);
	//return 0;
      }
}
